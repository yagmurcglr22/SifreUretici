﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime;

namespace SirfreUretici
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int length;
        string[] specials = { "!", "#", "@", "'", "$", "*", "+", "-", "/", ",", ";", ":"};
        string[] letters = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p","q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
        string[] lettersCap = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        string[] numbers = { "1", "2", "4", "5", "6", "7", "8", "9", "0" };

        private void button2_Click(object sender, EventArgs e)
        {
            int aA = 0;
          label1.Text = "";
            int res = 8;
            if(int.TryParse(textBox1.Text, out int wewa))
            {
                res = (int)wewa;
            }
            string generated = "";
            while(res > aA++)
            {

                generated += RandomVal((aA+1) * DateTime.Now.Millisecond);
            }

            label1.Text = generated;
            //label1.Text = CreatePassword(8);
        }
        string RandomVal(int i)
        {
            
            Random rng = new Random(i*88);
            int a = rng.Next(4);
            string generated = "";
          
            switch (a)
            {

                case 0:
                    Random r1 = new Random(i * i * DateTime.UtcNow.Millisecond);
                    int ar1 = r1.Next(specials.Length);
                    generated += specials[ar1].ToString();
                    break;
                case 1:
                    Random r2 = new Random(i*i*i * DateTime.UtcNow.Millisecond *2 );
                    int ar2 = r2.Next(letters.Length);
                    generated += letters[ar2].ToString();
                    break;
                case 2:
                    Random r3 = new Random(i*i*i*i * DateTime.UtcNow.Millisecond*3);
                    int ar3 = r3.Next(lettersCap.Length);
                    generated += letters[ar3].ToString();
                    break;
                case 3:
                    Random r = new Random(i*i*i*i*i * DateTime.UtcNow.Millisecond*4);
                    int ar = r.Next(numbers.Length);
                    generated += numbers[ar].ToString();
                    break;

            }
            a = rng.Next(4);
            return generated;
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(label1.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        bool isDragging;
        Size offset;
        private void label5_MouseDown(object sender, MouseEventArgs e)
        {
            offset = new Size(MousePosition.X - Location.X, MousePosition.Y - Location.Y);  
            isDragging = true;
        }

        private void label5_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging =false;  
        }

        private void label5_MouseHover(object sender, EventArgs e)
        {
       
        }

        private void label5_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                Location = MousePosition - offset;
            }
        }
    }
}
